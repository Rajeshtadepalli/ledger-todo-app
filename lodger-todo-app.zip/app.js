(() => {
  'use strict';

  /* ============================================================
     CONSTANTS & DOM REFERENCES
     ============================================================ */
  const STORAGE_KEY = 'ledger.tasks.v1';

  const els = {
    form:        document.getElementById('entryForm'),
    input:       document.getElementById('taskInput'),
    list:        document.getElementById('taskList'),
    template:    document.getElementById('taskTemplate'),
    emptyState:  document.getElementById('emptyState'),
    filters:     document.querySelectorAll('.filter-btn'),
    clearBtn:    document.getElementById('clearCompleted'),
    tallyCount:  document.getElementById('tallyCount'),
    tallyDone:   document.getElementById('tallyDone'),
    tallyTotal:  document.getElementById('tallyTotal'),
    todayDate:   document.getElementById('todayDate'),
  };

  /* ============================================================
     STATE
     tasks:  [{ id, text, completed, createdAt }]
     filter: 'all' | 'active' | 'completed'
     ============================================================ */
  let tasks = [];
  let filter = 'all';

  /* ============================================================
     PERSISTENCE — window.localStorage
     ============================================================ */
  function saveTasks() {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (err) {
      // Storage may be unavailable (private browsing, quota, sandboxed iframe).
      console.warn('Could not save tasks to localStorage:', err);
    }
  }

  function loadTasks() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      // Defensive validation in case storage was edited by hand.
      return parsed.filter(t =>
        t && typeof t.id === 'string' &&
        typeof t.text === 'string' &&
        typeof t.completed === 'boolean'
      );
    } catch (err) {
      console.warn('Could not load tasks from localStorage:', err);
      return [];
    }
  }

  /* ============================================================
     ID GENERATION
     ============================================================ */
  function makeId() {
    return (crypto.randomUUID) ? crypto.randomUUID()
      : 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2);
  }

  /* ============================================================
     CRUD OPERATIONS
     ============================================================ */
  function createTask(text) {
    const trimmed = text.trim();
    if (!trimmed) return;
    tasks.unshift({
      id: makeId(),
      text: trimmed,
      completed: false,
      createdAt: Date.now(),
    });
    saveTasks();
    render();
  }

  function updateTaskText(id, newText) {
    const trimmed = newText.trim();
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    if (!trimmed) {
      deleteTask(id); // clearing text out entirely removes the row
      return;
    }
    task.text = trimmed;
    saveTasks();
    render();
  }

  function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    task.completed = !task.completed;
    saveTasks();
    render();
  }

  function deleteTask(id) {
    const row = els.list.querySelector(`[data-id="${CSS.escape(id)}"]`);
    const removeFromState = () => {
      tasks = tasks.filter(t => t.id !== id);
      saveTasks();
      render();
    };
    if (row) {
      row.classList.add('is-removing');
      row.addEventListener('animationend', removeFromState, { once: true });
    } else {
      removeFromState();
    }
  }

  function clearCompleted() {
    tasks = tasks.filter(t => !t.completed);
    saveTasks();
    render();
  }

  /* ============================================================
     FILTERING (Read, derived view)
     ============================================================ */
  function getVisibleTasks() {
    if (filter === 'active') return tasks.filter(t => !t.completed);
    if (filter === 'completed') return tasks.filter(t => t.completed);
    return tasks;
  }

  function setFilter(next) {
    filter = next;
    els.filters.forEach(btn => {
      const isActive = btn.dataset.filter === filter;
      btn.classList.toggle('is-active', isActive);
      btn.setAttribute('aria-selected', String(isActive));
    });
    render();
  }

  /* ============================================================
     RENDERING — builds DOM from state via <template>
     ============================================================ */
  function render() {
    const visible = getVisibleTasks();

    els.list.innerHTML = '';
    const fragment = document.createDocumentFragment();

    visible.forEach((task, index) => {
      const node = els.template.content.firstElementChild.cloneNode(true);
      node.dataset.id = task.id;
      node.classList.toggle('is-done', task.completed);

      const checkbox = node.querySelector('.task-checkbox');
      checkbox.checked = task.completed;

      const textEl = node.querySelector('.task-text');
      textEl.textContent = task.text;

      const indexEl = node.querySelector('.task-index');
      indexEl.textContent = String(index + 1).padStart(2, '0');

      fragment.appendChild(node);
    });

    els.list.appendChild(fragment);

    els.emptyState.hidden = tasks.length !== 0;
    if (tasks.length === 0) {
      els.emptyState.textContent = 'Nothing on the ledger yet — add your first line item above.';
    } else if (visible.length === 0) {
      els.emptyState.hidden = false;
      els.emptyState.textContent = filter === 'completed'
        ? 'No completed tasks yet.'
        : 'No active tasks — everything is checked off.';
    }

    updateTally();
  }

  function updateTally() {
    const activeCount = tasks.filter(t => !t.completed).length;
    const doneCount = tasks.length - activeCount;
    els.tallyCount.textContent = `${activeCount} open`;
    els.tallyDone.textContent = `${doneCount} closed`;
    els.tallyTotal.textContent = `Total ${tasks.length}`;
    els.clearBtn.disabled = doneCount === 0;
  }

  /* ============================================================
     INLINE EDIT (Update, via double-click)
     ============================================================ */
  function startEdit(row) {
    const textEl = row.querySelector('.task-text');
    const inputEl = row.querySelector('.task-edit-input');
    const id = row.dataset.id;

    inputEl.value = textEl.textContent;
    textEl.hidden = true;
    inputEl.hidden = false;
    inputEl.focus();
    inputEl.setSelectionRange(inputEl.value.length, inputEl.value.length);

    const finish = (commit) => {
      inputEl.removeEventListener('blur', onBlur);
      inputEl.removeEventListener('keydown', onKeydown);
      if (commit) updateTaskText(id, inputEl.value);
      else { textEl.hidden = false; inputEl.hidden = true; }
    };
    const onBlur = () => finish(true);
    const onKeydown = (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    };

    inputEl.addEventListener('blur', onBlur);
    inputEl.addEventListener('keydown', onKeydown);
  }

  /* ============================================================
     EVENT LISTENERS
     ============================================================ */

  // Create
  els.form.addEventListener('submit', (e) => {
    e.preventDefault();
    createTask(els.input.value);
    els.input.value = '';
    els.input.focus();
  });

  // Delegated listeners on the list — handles toggle, delete, edit-open
  // for any number of dynamically created rows without per-row binding.
  els.list.addEventListener('click', (e) => {
    const row = e.target.closest('.task-row');
    if (!row) return;
    const id = row.dataset.id;

    if (e.target.closest('.task-delete')) {
      deleteTask(id);
      return;
    }
  });

  els.list.addEventListener('change', (e) => {
    if (e.target.classList.contains('task-checkbox')) {
      const row = e.target.closest('.task-row');
      toggleTask(row.dataset.id);
    }
  });

  els.list.addEventListener('dblclick', (e) => {
    const textEl = e.target.closest('.task-text');
    if (!textEl) return;
    startEdit(textEl.closest('.task-row'));
  });

  // Keyboard access: Enter on a focused task-text also opens edit mode
  els.list.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.classList.contains('task-text')) {
      startEdit(e.target.closest('.task-row'));
    }
  });

  // Filters
  els.filters.forEach(btn => {
    btn.addEventListener('click', () => setFilter(btn.dataset.filter));
  });

  // Clear completed
  els.clearBtn.addEventListener('click', clearCompleted);

  /* ============================================================
     INIT
     ============================================================ */
  function init() {
    tasks = loadTasks();
    els.todayDate.textContent = new Date().toLocaleDateString(undefined, {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    });
    render();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
